# Extrator bruto — canaletas Curitiba

Execute em Ubuntu:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install requests shapely
python extrair.py
```

Arquivos gerados: `canaletas_curitiba.geojson`, `cruzamentos_canaletas_curitiba.csv` e `rede_emergencia_curitiba.json`.

**Atenção:** busca somente candidatos marcados no OpenStreetMap como `highway=busway`, `service=busway` ou nome contendo canaleta/BRT. Pode omitir canaletas reais. Cruzamentos são interseções geométricas e não confirmam acesso, nível da via ou possibilidade de conversão. Verifique URBS, IPPUC, legislação, sinalização e campo. Não utilize diretamente para navegação de ambulâncias.

Fonte: © OpenStreetMap contributors (ODbL). https://www.openstreetmap.org/copyright
